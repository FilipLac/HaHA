----------------------------------
HaHA - Halloween Hunting Adventure
----------------------------------
Goal: The main objective is to finish this schoolday early and leave through the portal. The portal is located outside of the school (the blue orb).
To escape, you have to finish a task, that is someone will give you in school.

-----------
How to play
-----------
↑↓←→ keys for movement
Left Shift for sprint
Enter for interactions and dialogs (you must stand before the character, or on the object that you want to interact with)
ESC (Escape) key for menu, there you can use Options, or save the game.